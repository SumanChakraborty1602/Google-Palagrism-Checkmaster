# Google-PalagrismCheck
Plagriasm checker by using google search engine as source.

1. open the zip file as a Maven project
2. Run mainWindow.java snippet and allow firewall permission.
